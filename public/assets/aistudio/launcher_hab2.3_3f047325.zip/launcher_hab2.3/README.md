# Launcher Hab 2.3

Лёгкий лаунчер на **Flet** с акцентом на скорость, удобство и аккуратный интерфейс.

## Что есть сейчас

- запуск системных и web-приложений;
- категории, поиск и фильтрация;
- темы и базовая кастомизация;
- настройка формата времени/даты;
- настройка шрифта и размеров времени/даты;
- менеджер плагинов (включение, выключение, перезагрузка);
- резервные копии настроек;
- логирование в `logs/launcher.log`.

## Структура проекта

```text
launcher_hab2.3/
├── main.py
├── requirements.txt
├── plugins/
│   └── example_plugin.py
└── modules/
    ├── ui_manager_core.py
    ├── ui_panels.py
    ├── ui_dialogs.py
    ├── theme_manager.py
    ├── plugin_manager.py
    ├── logger.py
    └── ...
```

## Установка

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Запуск

```bash
python main.py
```

## Плагины

Плагины размещаются в папке `plugins/`.

Минимальный контракт плагина:

```python
def initialize_plugin():
    return PluginObject()
```

Опционально объект плагина может иметь:

- `get_ui_component()` — вернуть UI-элемент Flet;
- `cleanup()` — очистка при выгрузке.

## Примечания

- Для иконки приложения добавьте файл `assets/app_icon.png`.
- Добавлены рабочие плагины: Focus Mode, Smart Weather, Smart Music, Smart File Finder, Idea Notebook.
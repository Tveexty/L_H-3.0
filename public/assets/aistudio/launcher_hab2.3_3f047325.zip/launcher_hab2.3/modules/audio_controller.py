# [file name]: audio_controller.py
import flet as ft
import os
import subprocess
import platform
import threading

class AudioController:
    def __init__(self):
        self.system = platform.system()
    
    def get_volume_level(self):
        """Получить текущий уровень громкости через PowerShell"""
        try:
            if self.system == "Windows":
                result = subprocess.run(
                    ["powershell", "-Command", "(Get-AudioDevice -Playback).Volume"],
                    capture_output=True, text=True, timeout=3,
                    creationflags=subprocess.CREATE_NO_WINDOW
                )
                if result.returncode == 0:
                    return int(result.stdout.strip())
        except:
            pass
        return 50
    
    def set_volume_level(self, volume):
        """Установить уровень громкости через PowerShell"""
        try:
            if self.system == "Windows":
                # Используем Windows API через PowerShell для точной установки громкости
                script = f"""
                Add-Type -TypeDefinition @'
                using System.Runtime.InteropServices;
                public class AudioManager {{
                    [DllImport("user32.dll")]
                    public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, int dwExtraInfo);
                }}
                '@
                
                # Устанавливаем точную громкость через Windows Mixer API
                $code = @"
                using System;
                using System.Runtime.InteropServices;
                
                public class AudioVolume {{
                    [DllImport("user32.dll")]
                    static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, int dwExtraInfo);
                    
                    public static void SetVolume(int volume) {{
                        // Сбрасываем к 0
                        for(int i=0; i<50; i++) {{
                            keybd_event(0xAE, 0, 0x0001, 0); // Volume Down
                        }}
                        // Устанавливаем нужный уровень
                        int steps = volume / 2;
                        for(int i=0; i<steps; i++) {{
                            keybd_event(0xAF, 0, 0x0001, 0); // Volume Up
                        }}
                    }}
                }}
                "@
                Add-Type -TypeDefinition $code -Language CSharp
                [AudioVolume]::SetVolume({volume})
                """
                subprocess.run(
                    ["powershell", "-Command", script], 
                    timeout=5, 
                    shell=True,
                    creationflags=subprocess.CREATE_NO_WINDOW
                )
                return True
        except Exception as e:
            print(f"Ошибка установки громкости: {e}")
        return False
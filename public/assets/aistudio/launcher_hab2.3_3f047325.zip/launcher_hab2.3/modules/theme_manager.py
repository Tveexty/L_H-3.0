# [file name]: theme_manager.py
import flet as ft
import json
import os
from .file_manager import FileManager
from .logger import get_logger

logger = get_logger(__name__)

class ThemeManager:
    BASE_THEMES = {
        "dark": {
            "NAME": "Темная",
            "BG": "#1e1e1e",
            "SURFACE": "#2d2d2d",
            "SURFACE_VARIANT": "#3d3d3d",
            "ON_SURFACE": "#ffffff",
            "ON_SURFACE_VARIANT": "#cccccc",
            "OUTLINE": "#444444",
            "ACCENT": "#4285f4",
            "ACCENT_GLOW": "#4285f440",
            "ERROR": "#ff6b6b",
            "SUCCESS": "#4caf50",
            "WEB_BLUE": "#4285f4",
            "GLASS_BG": "#2d2d2d80",
            "GLASS_BORDER": "#ffffff20",
            "GLASS_SHADOW": "#00000040",
            "GLASS_BG_LIGHT": "#2d2d2d40",
            "SETTINGS_BG": "#1e1e1e",
            "SETTINGS_SURFACE": "#2d2d2d",
            "SETTINGS_CARD": "#3d3d3d"
        },
        "light": {
            "NAME": "Светлая", 
            "BG": "#f8fafc",
            "SURFACE": "#ffffff",
            "SURFACE_VARIANT": "#f1f5f9",
            "ON_SURFACE": "#0f172a",
            "ON_SURFACE_VARIANT": "#64748b",
            "OUTLINE": "#e2e8f0",
            "ACCENT": "#6366f1",
            "ACCENT_GLOW": "#6366f110",
            "ERROR": "#dc2626",
            "SUCCESS": "#059669",
            "WEB_BLUE": "#2563eb",
            "GLASS_BG": "#ffffff80",
            "GLASS_BORDER": "#00000008",
            "GLASS_SHADOW": "#00000010",
            "GLASS_BG_LIGHT": "#ffffff40",
            "SETTINGS_BG": "#f8fafc",
            "SETTINGS_SURFACE": "#ffffff",
            "SETTINGS_CARD": "#f1f5f9"
        },
        "purple": {
            "NAME": "Фиолетовая",
            "BG": "#1a1a2e",
            "SURFACE": "#2d2b55",
            "SURFACE_VARIANT": "#3d3a75",
            "ON_SURFACE": "#ffffff",
            "ON_SURFACE_VARIANT": "#d8c3f8",
            "OUTLINE": "#4a4788",
            "ACCENT": "#9c27b0",
            "ACCENT_GLOW": "#9c27b020",
            "ERROR": "#ff6b6b",
            "SUCCESS": "#4caf50",
            "WEB_BLUE": "#9c27b0",
            "GLASS_BG": "#2d2b5580",
            "GLASS_BORDER": "#ffffff08",
            "GLASS_SHADOW": "#00000040",
            "GLASS_BG_LIGHT": "#2d2b5540",
            "SETTINGS_BG": "#1a1a2e",
            "SETTINGS_SURFACE": "#2d2b55",
            "SETTINGS_CARD": "#3d3a75"
        },
        "spring": {
            "NAME": "Весна",
            "BG": "#fff9f9",
            "SURFACE": "#f8bbd0",
            "SURFACE_VARIANT": "#f48fb1",
            "ON_SURFACE": "#4a148c",
            "ON_SURFACE_VARIANT": "#880e4f",
            "OUTLINE": "#f06292",
            "ACCENT": "#e91e63",
            "ACCENT_GLOW": "#e91e6310",
            "ERROR": "#f44336",
            "SUCCESS": "#4caf50",
            "WEB_BLUE": "#e91e63",
            "GLASS_BG": "#f8bbd080",
            "GLASS_BORDER": "#4a148c08",
            "GLASS_SHADOW": "#00000020",
            "GLASS_BG_LIGHT": "#f8bbd040",
            "SETTINGS_BG": "#fff9f9",
            "SETTINGS_SURFACE": "#f8bbd0",
            "SETTINGS_CARD": "#f48fb1"
        }
    }
    
    def __init__(self):
        self.file_manager = FileManager()
        self.custom_themes = self.load_custom_themes()
        self.load_settings()
        self.smooth_animations = True
        self.android_animations = True
    
    def load_settings(self):
        settings = self.file_manager.load_settings()
        if settings is None:
            settings = {}
        
        # Существующие настройки
        self.current_theme = settings.get("theme", "dark")
        self.glass_effect_enabled = settings.get("glass_effect", True)
        self.glass_intensity = settings.get("glass_intensity", "medium")
        self.advanced_glass_enabled = settings.get("advanced_glass_enabled", False)
        self.advanced_glass_opacity = settings.get("advanced_glass_opacity", 50)
        self.desktop_mode_enabled = settings.get("desktop_mode_enabled", True)
        self.smooth_animations = settings.get("smooth_animations", True)
        self.android_animations = settings.get("android_animations", True)
        
        # НОВЫЕ НАСТРОЙКИ ДЛЯ ВЕРСИИ 2.2
        self.time_format = settings.get("time_format", "24")  # 12 или 24
        self.date_format = settings.get("date_format", "dd.mm.yyyy")
        self.font_family = settings.get("font_family", "Segoe UI")
        self.font_size = settings.get("font_size", 14)
        self.time_font_size = settings.get("time_font_size", 18)
        self.date_font_size = settings.get("date_font_size", 12)
        self.time_font_family = settings.get("time_font_family", self.font_family)
        self.date_font_family = settings.get("date_font_family", self.font_family)
        self.backup_auto = settings.get("backup_auto", True)
        self.backup_interval = settings.get("backup_interval", 7)  # дней
        self.search_cache_enabled = settings.get("search_cache_enabled", True)
        self.virtualization_enabled = settings.get("virtualization_enabled", True)
        self.clock_style = settings.get("clock_style", "standard")
        self.show_date = settings.get("show_date", True)
        self.time_color = settings.get("time_color", self.get_theme(self.current_theme).get("ON_SURFACE", "#ffffff"))
        self.date_color = settings.get("date_color", self.get_theme(self.current_theme).get("ON_SURFACE_VARIANT", "#cccccc"))
        self.search_history_enabled = settings.get("search_history_enabled", True)
    
    def save_settings(self):
        settings_data = {
            # Существующие настройки
            "theme": self.current_theme,
            "glass_effect": self.glass_effect_enabled,
            "glass_intensity": self.glass_intensity,
            "advanced_glass_enabled": self.advanced_glass_enabled,
            "advanced_glass_opacity": self.advanced_glass_opacity,
            "desktop_mode_enabled": self.desktop_mode_enabled,
            "smooth_animations": self.smooth_animations,
            "android_animations": self.android_animations,
            
            # НОВЫЕ НАСТРОЙКИ ДЛЯ ВЕРСИИ 2.2
            "time_format": self.time_format,
            "date_format": self.date_format,
            "font_family": self.font_family,
            "font_size": self.font_size,
            "time_font_size": self.time_font_size,
            "date_font_size": self.date_font_size,
            "time_font_family": self.time_font_family,
            "date_font_family": self.date_font_family,
             "backup_auto": self.backup_auto,
            "backup_interval": self.backup_interval,
            "search_cache_enabled": self.search_cache_enabled,
            "virtualization_enabled": self.virtualization_enabled,
            "clock_style": self.clock_style,
            "show_date": self.show_date,
            "time_color": self.time_color,
            "date_color": self.date_color,
            "search_history_enabled": self.search_history_enabled
        }
        return self.file_manager.save_settings(settings_data)
    
    def load_custom_themes(self):
        themes = self.file_manager.load_data('custom_themes.json', {})
        return themes if themes is not None else {}
    
    def save_custom_themes(self):
        self.file_manager.save_data('custom_themes.json', self.custom_themes)
    
    def get_theme(self, theme_name=None):
        theme_name = theme_name or self.current_theme
        all_themes = {**self.BASE_THEMES, **self.custom_themes}
        return all_themes.get(theme_name, self.BASE_THEMES["dark"])
    
    def get_current_theme(self):
        return self.get_theme(self.current_theme)
    
    def apply_theme(self, page, theme_name):
        if theme_name not in self.BASE_THEMES and theme_name not in self.custom_themes:
            theme_name = "dark"
            
        self.current_theme = theme_name
        theme = self.get_theme(theme_name)
        
        if page:
            page.bgcolor = theme["BG"]
            if theme_name in ["light", "spring"]:
                page.theme_mode = ft.ThemeMode.LIGHT
            else:
                page.theme_mode = ft.ThemeMode.DARK
            
            # Применить настройки шрифта
            try:
                page.theme = ft.Theme(
                    font_family=self.font_family,
                    page_transitions=ft.PageTransitionsTheme(
                        windows=ft.PageTransitionTheme.CUPERTINO,
                        linux=ft.PageTransitionTheme.CUPERTINO,
                        macos=ft.PageTransitionTheme.CUPERTINO
                    ) if self.smooth_animations else None
                )
            except Exception:
                logger.exception("Не удалось применить тему")
        
        self.save_settings()
        return theme
    
    def toggle_glass_effect(self):
        self.glass_effect_enabled = not self.glass_effect_enabled
        self.save_settings()
        return self.glass_effect_enabled
    
    def set_glass_intensity(self, intensity):
        if intensity in ["light", "medium", "strong"]:
            self.glass_intensity = intensity
            self.save_settings()
    
    def set_advanced_glass(self, enabled: bool, opacity: int = None):
        self.advanced_glass_enabled = bool(enabled)
        if opacity is not None:
            self.advanced_glass_opacity = max(25, min(100, int(opacity)))
        self.save_settings()

    def set_desktop_mode(self, enabled: bool):
        self.desktop_mode_enabled = bool(enabled)
        self.save_settings()

    def toggle_smooth_animations(self):
        self.smooth_animations = not self.smooth_animations
        self.save_settings()
        return self.smooth_animations

    def toggle_android_animations(self):
        self.android_animations = not self.android_animations
        self.save_settings()
        return self.android_animations

    def get_available_themes(self):
        return {**self.BASE_THEMES, **self.custom_themes}

    def add_custom_theme(self, name, theme_data):
        """Добавить кастомную тему"""
        if name and theme_data:
            self.custom_themes[name] = theme_data
            self.save_custom_themes()
            return True
        return False

    # НОВЫЕ МЕТОДЫ ДЛЯ ВЕРСИИ 2.2
    def set_time_format(self, format_type):
        """Установить формат времени"""
        if format_type in ["12", "24"]:
            self.time_format = format_type
            self.save_settings()
    
    def set_font_family(self, font_family):
        """Установить семейство шрифтов"""
        self.font_family = font_family
        self.save_settings()
    
    def set_font_size(self, font_size):
        """Установить размер шрифта"""
        self.font_size = font_size
        self.save_settings()
    
    def set_time_style(self, time_size=None, date_size=None, time_family=None, date_family=None):
        """Установить стили времени и даты"""
        if time_size is not None:
            self.time_font_size = int(time_size)
        if date_size is not None:
            self.date_font_size = int(date_size)
        if time_family:
            self.time_font_family = time_family
        if date_family:
            self.date_font_family = date_family
        self.save_settings()
    
    def set_backup_settings(self, auto_backup, interval):
        """Установить настройки резервного копирования"""
        self.backup_auto = auto_backup
        self.backup_interval = interval
        self.save_settings()
    
    def set_performance_settings(self, search_cache, virtualization):
        """Установить настройки производительности"""
        self.search_cache_enabled = search_cache
        self.virtualization_enabled = virtualization
        self.save_settings()

    def set_clock_preferences(self, style=None, show_date=None, time_color=None, date_color=None):
        if style in ["standard", "stacked"]:
            self.clock_style = style
        if show_date is not None:
            self.show_date = bool(show_date)
        if isinstance(time_color, str) and time_color.startswith("#"):
            self.time_color = time_color
        if isinstance(date_color, str) and date_color.startswith("#"):
            self.date_color = date_color
        self.save_settings()
# [file name]: plugin_manager.py
import flet as ft
import importlib.util
import os
import sys
from pathlib import Path
from typing import Any, Dict

from .logger import get_logger

logger = get_logger(__name__)


class PluginManager:
    def __init__(self, file_manager):
        self.file_manager = file_manager
        self.plugins_dir = Path("plugins")
        self.plugins_file = "plugins.json"
        self.loaded_plugins: Dict[str, Any] = {}
        self.context = None

        self.plugins_dir.mkdir(exist_ok=True)
        self.available_plugins = self.load_plugins_list()
        self.refresh_plugins(load_enabled=True)

    def load_plugins_list(self) -> Dict[str, Dict[str, Any]]:
        """Загрузить список плагинов."""
        data = self.file_manager.load_data(self.plugins_file, {})
        return data if isinstance(data, dict) else {}

    def save_plugins_list(self) -> bool:
        """Сохранить список плагинов."""
        return self.file_manager.save_data(self.plugins_file, self.available_plugins)

    def discover_plugins(self) -> Dict[str, Dict[str, Any]]:
        """Обнаружить плагины в директории."""
        plugins: Dict[str, Dict[str, Any]] = {}
        for file_path in self.plugins_dir.glob("*.py"):
            if file_path.name.startswith("_"):
                continue

            plugin_name = file_path.stem
            plugins[plugin_name] = {
                "name": plugin_name,
                "enabled": self.available_plugins.get(plugin_name, {}).get("enabled", False),
                "path": str(file_path.resolve()),
            }
        return plugins

    def load_plugin(self, plugin_name: str) -> bool:
        """Загрузить плагин."""
        if plugin_name in self.loaded_plugins:
            return True

        plugin_info = self.available_plugins.get(plugin_name)
        if not plugin_info or not plugin_info.get("enabled", False):
            return False

        plugin_path = plugin_info.get("path")
        if not plugin_path or not os.path.exists(plugin_path):
            logger.warning("Файл плагина %s не найден: %s", plugin_name, plugin_path)
            return False

        module_name = f"launcher_plugin_{plugin_name}"
        try:
            spec = importlib.util.spec_from_file_location(module_name, plugin_path)
            if spec is None or spec.loader is None:
                logger.error("Не удалось создать spec для плагина %s", plugin_name)
                return False

            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            spec.loader.exec_module(module)

            if not hasattr(module, "initialize_plugin"):
                logger.error("Плагин %s не содержит initialize_plugin()", plugin_name)
                return False

            plugin_instance = module.initialize_plugin()
            if self.context and hasattr(plugin_instance, "set_context"):
                plugin_instance.set_context(self.context)
            self.loaded_plugins[plugin_name] = {
                "instance": plugin_instance,
                "module_name": module_name,
            }
            logger.info("Плагин загружен: %s", plugin_name)
            return True
        except Exception:
            logger.exception("Ошибка загрузки плагина %s", plugin_name)
            return False

    def unload_plugin(self, plugin_name: str) -> bool:
        """Выгрузить плагин."""
        plugin_data = self.loaded_plugins.get(plugin_name)
        if not plugin_data:
            return False

        try:
            plugin_instance = plugin_data.get("instance")
            if hasattr(plugin_instance, "cleanup"):
                plugin_instance.cleanup()

            module_name = plugin_data.get("module_name")
            if module_name and module_name in sys.modules:
                del sys.modules[module_name]

            del self.loaded_plugins[plugin_name]
            logger.info("Плагин выгружен: %s", plugin_name)
            return True
        except Exception:
            logger.exception("Ошибка выгрузки плагина %s", plugin_name)
            return False

    def enable_plugin(self, plugin_name: str) -> bool:
        if plugin_name not in self.available_plugins:
            return False

        self.available_plugins[plugin_name]["enabled"] = True
        self.save_plugins_list()
        return self.load_plugin(plugin_name)

    def disable_plugin(self, plugin_name: str) -> bool:
        if plugin_name not in self.available_plugins:
            return False

        self.available_plugins[plugin_name]["enabled"] = False
        self.save_plugins_list()
        self.unload_plugin(plugin_name)
        return True

    def refresh_plugins(self, load_enabled: bool = False):
        """Обновить список плагинов."""
        discovered = self.discover_plugins()

        removed_plugins = set(self.available_plugins.keys()) - set(discovered.keys())
        for plugin_name in removed_plugins:
            self.unload_plugin(plugin_name)

        self.available_plugins = discovered
        self.save_plugins_list()

        if load_enabled:
            for plugin_name, plugin_info in self.available_plugins.items():
                if plugin_info.get("enabled", False):
                    self.load_plugin(plugin_name)


    def set_context(self, context):
        self.context = context
        for plugin_data in self.loaded_plugins.values():
            plugin_instance = plugin_data.get("instance")
            if plugin_instance and hasattr(plugin_instance, "set_context"):
                plugin_instance.set_context(context)

    def get_plugin_ui(self, plugin_name: str):
        plugin_data = self.loaded_plugins.get(plugin_name)
        if not plugin_data:
            return None

        plugin_instance = plugin_data.get("instance")
        if hasattr(plugin_instance, "get_ui_component"):
            return plugin_instance.get_ui_component()
        return None

    def create_plugin_ui(self, colors):
        self.refresh_plugins(load_enabled=False)

        plugin_cards = []
        for plugin_name, plugin_info in self.available_plugins.items():
            is_enabled = plugin_info.get("enabled", False)
            is_loaded = plugin_name in self.loaded_plugins

            status_text = "🟢 Загружен" if is_loaded else "🔴 Выключен"
            status_color = colors["SUCCESS"] if is_loaded else colors["ERROR"]

            plugin_widget = self.get_plugin_ui(plugin_name) if is_loaded else None

            plugin_cards.append(
                ft.Container(
                    content=ft.Column([
                        ft.Row([
                            ft.Icon("extension", color=colors["ACCENT"], size=20),
                            ft.Text(plugin_name, weight=ft.FontWeight.BOLD, expand=True),
                            ft.Container(
                                content=ft.Text(status_text, size=12, color=status_color),
                                bgcolor=colors["SURFACE_VARIANT"] + "30",
                                padding=ft.padding.symmetric(horizontal=8, vertical=4),
                                border_radius=8,
                            ),
                        ]),
                        ft.Container(height=5),
                        ft.Row([
                            ft.Switch(
                                value=is_enabled,
                                on_change=lambda e, pn=plugin_name: self.toggle_plugin(pn, e),
                                active_track_color=colors["ACCENT"],
                            ),
                            ft.Text("Включен", size=12, color=colors["ON_SURFACE_VARIANT"]),
                            ft.Container(width=20),
                            ft.IconButton(
                                icon="refresh",
                                icon_size=16,
                                on_click=lambda e, pn=plugin_name: self.reload_plugin(pn, e),
                                tooltip="Перезагрузить плагин",
                            ),
                        ]),
                        plugin_widget if plugin_widget else ft.Container(),
                    ]),
                    bgcolor=colors["SETTINGS_CARD"],
                    border_radius=12,
                    padding=15,
                    margin=ft.margin.only(bottom=10),
                )
            )

        if not plugin_cards:
            plugin_cards.append(
                ft.Container(
                    content=ft.Column([
                        ft.Icon("extension", size=48, color=colors["ON_SURFACE_VARIANT"]),
                        ft.Text("Плагины не найдены", size=16, weight=ft.FontWeight.BOLD),
                        ft.Text("Добавьте файлы плагинов в папку 'plugins'", size=12, color=colors["ON_SURFACE_VARIANT"]),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=10),
                    padding=40,
                    alignment=ft.alignment.center,
                )
            )

        return ft.Column([
            ft.Text("Управление плагинами", size=20, weight=ft.FontWeight.BOLD),
            ft.Text("Расширьте функциональность лаунчера с помощью плагинов", size=14, color=colors["ON_SURFACE_VARIANT"]),
            ft.Container(height=20),
            *plugin_cards,
        ], scroll=ft.ScrollMode.ADAPTIVE)

    def toggle_plugin(self, plugin_name, e):
        if e.control.value:
            self.enable_plugin(plugin_name)
        else:
            self.disable_plugin(plugin_name)
        e.page.update()

    def reload_plugin(self, plugin_name, e):
        self.unload_plugin(plugin_name)
        loaded = self.load_plugin(plugin_name)
        message = f"Плагин {plugin_name} перезагружен" if loaded else f"Не удалось загрузить плагин {plugin_name}"
        e.page.show_snack_bar(ft.SnackBar(content=ft.Text(message), action="OK"))
        e.page.update()

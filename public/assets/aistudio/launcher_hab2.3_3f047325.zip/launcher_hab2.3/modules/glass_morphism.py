import flet as ft

class GlassMorphism:
    @staticmethod
    def create_container(content, colors, intensity="medium", border=True, shadow=True):
        """Создание контейнера с правильным Glass Morphism эффектом"""
        
        # Правильные настройки для разных интенсивностей␊
        glass_styles = {
            "light": {
                "bg_blur": 5,
                "bg_opacity": 0.1,
                "border_opacity": 0.1,
                "shadow_blur": 8
            },
            "medium": {
                "bg_blur": 14,
                "bg_opacity": 0.2,
                "border_opacity": 0.2,
                "shadow_blur": 18
            },
            "strong": {
                "bg_blur": 26,
                "bg_opacity": 0.3,
                "border_opacity": 0.24,
                "shadow_blur": 22
            }
        }
        
        style = glass_styles.get(intensity, glass_styles["medium"])
        
        # Создаем правильный фон с размытием␊
        bg_color = GlassMorphism._apply_opacity(colors["SURFACE"], style["bg_opacity"])
        border_color = GlassMorphism._apply_opacity(colors["OUTLINE"], style["border_opacity"]) if border else None
        
        container = ft.Container(
            content=content,
            bgcolor=bg_color,
            border=ft.border.all(1, border_color) if border else None,
            border_radius=18,
            padding=16,
            margin=5,
            shadow=ft.BoxShadow(
                blur_radius=style["shadow_blur"], 
                color=colors["GLASS_SHADOW"], 
                offset=ft.Offset(0, 4)
            ) if shadow else None,
            animate=ft.Animation(300, "easeOut"),
        )
        
        return container
    
    @staticmethod
    def _apply_opacity(color, opacity):
        """Применяет прозрачность к HEX цвету"""
        if color.startswith("#") and len(color) == 7:
            # Конвертируем opacity в HEX␊
            opacity_hex = format(int(opacity * 255), '02x')
            return color + opacity_hex
        return color
    
    @staticmethod
    def create_app_button(app, colors, is_installed, is_favorite=False, glass_effect=True, on_click=None):
        if app["type"] == "web":
            icon_color = colors["WEB_BLUE"]
        else:
            icon_color = colors["ON_SURFACE"] if is_installed else colors["ERROR"]
        
        # Используем правильный Glass Morphism эффект
        if glass_effect:
            bg_color = GlassMorphism._apply_opacity(colors["SURFACE"], 0.1)
        else:
            bg_color = colors["SURFACE_VARIANT"] + "30"
        
        icon_container = ft.Container(
            content=ft.Stack([
                ft.Icon(name=app["icon"], size=42, color=icon_color),
                ft.Container(
                    content=ft.Icon(
                        name="check_circle" if is_installed else "error",
                        size=16,
                        color=colors["SUCCESS"] if is_installed else colors["ERROR"]
                    ) if not is_favorite else ft.Icon(name="star", size=16, color=colors["ACCENT"]),
                    alignment=ft.alignment.bottom_right,
                    margin=ft.margin.only(top=-18, right=-5),
                )
            ]),
            width=80,
            height=80,
            alignment=ft.alignment.center,
            bgcolor=bg_color,
            border_radius=15,
            border=ft.border.all(1, GlassMorphism._apply_opacity(colors["OUTLINE"], 0.1)) if glass_effect else None,
            shadow=ft.BoxShadow(blur_radius=8, color=colors["GLASS_SHADOW"], offset=ft.Offset(0, 2)),
        )
        
        app_content = ft.Column([
            icon_container,
            ft.Container(
                content=ft.Text(
                    app["name"],
                    size=13,
                    color=icon_color,
                    text_align=ft.TextAlign.CENTER,
                    max_lines=2,
                    overflow=ft.TextOverflow.ELLIPSIS,
                ),
                height=40,
                alignment=ft.alignment.top_center,
                padding=ft.padding.only(top=5)
            )
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=5, height=130)
        
        app_container = ft.Container(
            content=app_content,
            width=110,
            height=140,
            padding=10,
            on_click=on_click,
            tooltip=f"Запустить {app['name']}",
            border_radius=12,
            bgcolor="transparent",
            animate=ft.Animation(200, "easeOut"),
        )
        
        return app_container

    @staticmethod
    def create_card(content, colors, hover_effect=True, intensity="medium"):
        """Создание карточки с правильным Glass Morphism эффектом"""
        
        glass_styles = {
            "light": {"opacity": 0.1, "blur": 5},
            "medium": {"opacity": 0.15, "blur": 10},
            "strong": {"opacity": 0.25, "blur": 20}
        }
        
        style = glass_styles.get(intensity, glass_styles["medium"])
        
        card = ft.Container(
            content=content,
            bgcolor=GlassMorphism._apply_opacity(colors["SURFACE"], style["opacity"]),
            border=ft.border.all(1.2, GlassMorphism._apply_opacity(colors["OUTLINE"], 0.22)),
            border_radius=20,
            padding=20,
            margin=10,
            shadow=ft.BoxShadow(
                blur_radius=style["blur"], 
                color=colors["GLASS_SHADOW"], 
                offset=ft.Offset(0, 8)
            ),
            animate=ft.Animation(300, "easeOut"),
        )
        
        if hover_effect:
            def on_hover(e):
                if e.data == "true":
                    card.scale = 1.02
                    card.bgcolor = GlassMorphism._apply_opacity(colors["ACCENT"], 0.1)
                else:
                    card.scale = 1.0
                    card.bgcolor = GlassMorphism._apply_opacity(colors["SURFACE"], style["opacity"])
                card.update()
            
            card.on_hover = on_hover
        
        return card
# [file name]: ui_manager_core.py
import flet as ft
import threading
import time
import os
import uuid
from datetime import datetime
from .theme_manager import ThemeManager
from .app_manager import AppManager
from .system_monitor import SystemMonitor
from .glass_morphism import GlassMorphism
from .backup_manager import BackupManager
from .cache_manager import CacheManager, SearchCache
from .logger import get_logger
from .hotkey_manager import HotkeyManager
from .smart_workspace_manager import SmartWorkspaceManager

# Условный импорт для обработки отсутствующих модулей
try:
    from .plugin_manager import PluginManager
except ImportError:
    class PluginManager:
        def __init__(self, file_manager):
            self.file_manager = file_manager
        
        def create_plugin_ui(self, colors):
            return ft.Container(
                content=ft.Column([
                    ft.Icon("extension", size=48, color=colors["ON_SURFACE_VARIANT"]),
                    ft.Text("Плагины недоступны", size=16, weight=ft.FontWeight.BOLD),
                    ft.Text("Установите зависимости для работы с плагинами", size=12, color=colors["ON_SURFACE_VARIANT"])
                ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=10),
                padding=40,
                alignment=ft.alignment.center
            )

try:
    from .audio_controller import AudioController
except ImportError:
    class AudioController:
        def __init__(self):
            pass
        
        def get_volume_level(self):
            return 50
        
        def set_volume_level(self, volume):
            pass
        
        def create_compact_audio_ui(self, colors):
            return ft.Container(
                content=ft.Row([
                    ft.IconButton(icon="volume_up", icon_size=20, icon_color=colors["ACCENT"]),
                    ft.Text("Аудио контроллер недоступен", size=12, color=colors["ON_SURFACE_VARIANT"])
                ]),
                bgcolor=colors["SETTINGS_CARD"],
                border_radius=12,
                padding=10,
                margin=ft.margin.only(bottom=10),
            )

logger = get_logger(__name__)

class UIManagerCore:
    def __init__(self, page: ft.Page):
        self.page = page
        self.theme_manager = ThemeManager()
        self.app_manager = AppManager()
        self.system_monitor = SystemMonitor()
        self.plugin_manager = self._safe_create_plugin_manager()
        if hasattr(self.plugin_manager, "set_context"):
            self.plugin_manager.set_context(self)
        self.audio_controller = self._safe_create_audio_controller()
        self.backup_manager = BackupManager(self.app_manager.file_manager)
        self.cache_manager = CacheManager()
        self.search_cache = SearchCache()
        self.smart_workspace_manager = SmartWorkspaceManager(self.app_manager.file_manager, self.app_manager)
        self.hotkey_manager = HotkeyManager(self)
        self.floating_hud_visible = False
        self.floating_hud = None
        self.floating_hud_cpu_text = None
        self.floating_hud_ram_text = None
        self.floating_hud_apps_text = None
        self.search_history_file = "search_history.json"
        
        # Импортируем панели и диалоги
        from .ui_panels import UIPanels
        from .ui_dialogs import UIDialogs
        
        self.panels = UIPanels(self)
        self.dialogs = UIDialogs(self)
        
        # Состояние
        self.current_filter = "all"
        self.filter_dialog_open = False
        self.auto_update_enabled = True
        self.system_notifications_enabled = True
        self.volume_slider_visible = False
        self.search_history = self.load_search_history()
        
        # UI элементы
        self.header = None
        self.sidebar = None
        self.main_content = None
        self.loading_progress = None

        # Горячие клавиши отключены
        self.setup_hotkeys()

    def setup_hotkeys(self):
        """Инициализация горячих клавиш с защитой от несовместимых версий Flet."""
        try:
            if hasattr(self.page, "on_keyboard_event"):
                self.page.on_keyboard_event = self.hotkey_manager.handle_keyboard
            else:
                logger.warning("Текущая версия Flet не поддерживает on_keyboard_event")
        except Exception:
            logger.exception("Не удалось подключить обработчик горячих клавиш")

    def _safe_create_plugin_manager(self):
        """Безопасное создание менеджера плагинов."""
        try:
            return PluginManager(self.app_manager.file_manager)
        except Exception:
            logger.exception("PluginManager не инициализирован; используем запасной режим")

            class _FallbackPluginManager:
                def set_context(self, _context):
                    return None

                def create_plugin_ui(self, colors):
                    return ft.Container(
                        content=ft.Text(
                            "PluginManager недоступен в этом запуске",
                            color=colors["ON_SURFACE_VARIANT"],
                        ),
                        padding=12,
                    )

            return _FallbackPluginManager()

    def _safe_create_audio_controller(self):
        """Безопасное создание аудио-контроллера."""
        try:
            return AudioController()
        except Exception:
            logger.exception("AudioController не инициализирован; используем запасной режим")

            class _FallbackAudioController:
                def get_volume_level(self):
                    return 50

                def set_volume_level(self, _volume):
                    return None

            return _FallbackAudioController()

    def initialize_ui(self):
        self.setup_page()
        self.create_ui_elements()
        self.setup_timers()
        self.apply_initial_theme()
        
        # Автоматическое резервное копирование при запуске
        if hasattr(self.theme_manager, 'backup_auto') and self.theme_manager.backup_auto:
            threading.Thread(target=self.backup_manager.auto_backup, daemon=True).start()

    def setup_page(self):
        self.page.title = "Launcher Hab 2.3"
        self.page.padding = 0
        self.page.spacing = 0
        self.page.theme_mode = ft.ThemeMode.DARK
        self.page.bgcolor = "#1e1e1e"
        
        # Применяем настройки шрифта
        try:
            self.page.theme = ft.Theme(
                font_family=self.theme_manager.font_family,
                page_transitions=ft.PageTransitionsTheme(
                    windows=ft.PageTransitionTheme.CUPERTINO,
                    linux=ft.PageTransitionTheme.CUPERTINO,
                    macos=ft.PageTransitionTheme.CUPERTINO
                ) if self.theme_manager.smooth_animations else None
            )
        except Exception:
            logger.exception("Ошибка настройки темы страницы")
        
        if hasattr(self.page, "on_scroll"):
            self.page.on_scroll = lambda e: None

        try:
            if hasattr(self.page, "on_window_event"):
                self.page.on_window_event = self.on_window_event
            else:
                logger.warning("Текущая версия Flet не поддерживает on_window_event")
        except Exception:
            logger.exception("Не удалось подключить обработчик событий окна")
        icon_candidate = os.path.join("assets", "app_icon.png")
        if os.path.exists(icon_candidate):
            self.page.window_icon = "app_icon.png"

    def create_ui_elements(self):
        self.header = self.panels.create_header()
        self.sidebar = self.panels.create_sidebar()
        self.main_content = self.panels.create_main_content()
        self.loading_progress = self.panels.create_loading_progress()

        content = ft.Row([
            self.sidebar,
            ft.VerticalDivider(width=1, color=self.get_colors()["OUTLINE"], thickness=1),
            ft.Container(content=self.main_content, expand=True, padding=0, margin=0),
        ], expand=True, spacing=0)

        recycle_fab = ft.Container(
            content=ft.IconButton(
                icon="delete_outline",
                icon_color=self.get_colors()["ON_SURFACE"],
                tooltip="Открыть корзину",
                on_click=lambda e: self.open_recycle_bin(),
            ),
            right=24,
            bottom=24,
            bgcolor=self.get_colors()["SURFACE"],
            border=ft.border.all(1, self.get_colors()["OUTLINE"]),
            border_radius=16,
            padding=6,
            shadow=ft.BoxShadow(blur_radius=12, color=self.get_colors()["GLASS_SHADOW"], offset=ft.Offset(0, 3)),
        )

        body = ft.Stack([content, recycle_fab], expand=True)
        self.page.add(self.header, body)
        self.update_interface_colors()

    def setup_timers(self):
        def time_timer():
            while True:
                self.update_time()
                time.sleep(1)
        
        def devices_timer():
            while True:
                self.update_devices_header()
                time.sleep(5)
        
        def backup_timer():
            while True:
                # Проверяем необходимость автоматического бэкапа каждые 24 часа
                if hasattr(self.theme_manager, 'backup_auto') and self.theme_manager.backup_auto:
                    self.backup_manager.auto_backup()
                time.sleep(86400)  # 24 часа
        
        threading.Thread(target=time_timer, daemon=True).start()
        threading.Thread(target=devices_timer, daemon=True).start()
        threading.Thread(target=backup_timer, daemon=True).start()

    def update_time(self):
        """Обновление времени и даты с учетом настроек формата"""
        if hasattr(self.panels, 'current_time_text') and self.panels.current_time_text:
            now = datetime.now()
            
            # Форматирование времени в зависимости от настроек
            if getattr(self.theme_manager, "clock_style", "standard") == "stacked":
                time_str = now.strftime("%H\n%M")
            elif hasattr(self.theme_manager, 'time_format') and self.theme_manager.time_format == "12":
                time_str = now.strftime("%I:%M:%S %p")
            else:
                time_str = now.strftime("%H:%M:%S")
            
            # Форматирование даты
            date_format = getattr(self.theme_manager, 'date_format', 'dd.mm.yyyy')
            if date_format == "mm/dd/yyyy":
                date_str = now.strftime("%m/%d/%Y")
            elif date_format == "yyyy-mm-dd":
                date_str = now.strftime("%Y-%m-%d")
            else:
                date_str = now.strftime("%d.%m.%Y")
            
            self.panels.current_time_text.value = time_str
            if hasattr(self.panels, 'current_date_text') and self.panels.current_date_text:
                self.panels.current_date_text.value = date_str
                self.panels.current_date_text.visible = getattr(self.theme_manager, "show_date", True)

            if hasattr(self.panels, "current_time_text") and self.panels.current_time_text:
                self.panels.current_time_text.color = getattr(self.theme_manager, "time_color", self.get_colors()["ON_SURFACE"])
            if hasattr(self.panels, "current_date_text") and self.panels.current_date_text:
                self.panels.current_date_text.color = getattr(self.theme_manager, "date_color", self.get_colors()["ON_SURFACE_VARIANT"])
            
            self.update_floating_hud_data()
            if hasattr(self, 'page'):
                self.page.update()

    def update_floating_hud_data(self):
        if not self.floating_hud_visible:
            return
        if not (self.floating_hud_cpu_text and self.floating_hud_ram_text and self.floating_hud_apps_text):
            return
        perf = self.system_monitor.get_performance_info()
        self.floating_hud_cpu_text.value = f"CPU {perf['cpu']}%"
        self.floating_hud_ram_text.value = f"RAM {perf['ram']}%"
        self.floating_hud_apps_text.value = f"Launch apps {len(self.app_manager.favorite_apps)}"

    def update_devices_header(self):
        if hasattr(self.panels, 'devices_container') and self.panels.devices_container:
            self.panels.devices_container.content = self.system_monitor.create_devices_header(self.get_colors())
            self.page.update()

    def apply_initial_theme(self):
        self.theme_manager.apply_theme(self.page, self.theme_manager.current_theme)
        self.update_interface_colors()
        self.update_time()

    def get_colors(self):
        return self.theme_manager.get_current_theme()

    def update_interface_colors(self):
        colors = self.get_colors()
        self.page.bgcolor = colors["BG"]
        
        if self.header:
            self.header.bgcolor = colors["SURFACE"]
        if self.sidebar:
            self.sidebar.bgcolor = colors["SURFACE"]
        if self.main_content:
            self.main_content.bgcolor = colors["BG"]
        
        self.page.update()

    def update_main_content(self):
        """Обновить основной контент"""
        if self.main_content:
            self.main_content.content = self.panels.create_main_content_internal()
            self.page.update()

    def update_sidebar(self):
        """Обновить сайдбар"""
        if self.sidebar:
            self.sidebar.content = self.panels.create_sidebar_content()
            self.page.update()

    def launch_app(self, app):
        """Запуск приложения"""
        success, message = self.app_manager.launch_app(app)
        if self.system_notifications_enabled:
            self.show_system_notification("Запуск приложения", message)

    def show_system_notification(self, title, message):
        if self.system_notifications_enabled:
            self.page.show_snack_bar(ft.SnackBar(
                content=ft.Column([
                    ft.Text(title, weight=ft.FontWeight.BOLD),
                    ft.Text(message, size=12)
                ], tight=True),
                action="OK",
                duration=3000
            ))

    def toggle_volume_slider(self, e):
        """Переключение видимости слайдера громкости"""
        self.volume_slider_visible = not self.volume_slider_visible
        if hasattr(self.panels, 'volume_slider_container'):
            self.panels.volume_slider_container.visible = self.volume_slider_visible
            self.panels.volume_slider_container.update()

    def on_volume_change(self, e):
        """Обработчик изменения громкости"""
        volume = int(e.control.value)
        threading.Thread(
            target=self.audio_controller.set_volume_level, 
            args=(volume,), 
            daemon=True
        ).start()
        
        e.control.label = f"{volume}%"
        e.control.update()

    def filter_apps(self, e):
        """Фильтрация приложений по поисковому запросу с использованием кэша"""
        query = e.control.value.lower().strip()
        
        # Сохраняем историю поиска
        if getattr(self.theme_manager, "search_history_enabled", True) and query and query not in self.search_history:
            self.search_history.append(query)
            if len(self.search_history) > 50:
                self.search_history.pop(0)
            self.save_search_history()
        
        if not query:
            self.update_main_content()
            return
        
        # Используем кэш поиска если включен
        all_apps = self.app_manager.all_apps + self.app_manager.custom_apps
        if hasattr(self.theme_manager, 'search_cache_enabled') and self.theme_manager.search_cache_enabled:
            results = self.search_cache.get_search_results(query, all_apps)
        else:
            results = [app for app in all_apps 
                      if query in app["name"].lower() or 
                         query in app["category"].lower() or
                         (app.get("tags") and query in app["tags"].lower())]
        
        self.panels.show_search_results(results, query)

    def show_filter_menu(self, e):
        self.dialogs.show_filter_menu(e)

    def on_window_event(self, e):
        """Возвращает окно при попытке свернуть (режим замены рабочего стола)."""
        try:
            if getattr(self.theme_manager, "desktop_mode_enabled", True) and getattr(e, "data", "") == "minimize":
                self.page.window_minimized = False
                self.page.window_full_screen = True
                self.page.window_to_front()
                self.page.update()
        except Exception:
            logger.exception("Ошибка обработки window event")


    def quick_add_idea(self):
        idea_field = ft.TextField(label="New idea", autofocus=True)

        def save_idea(_):
            idea = (idea_field.value or "").strip()
            if not idea:
                return
            with open("idea_notes.txt", "a", encoding="utf-8") as f:
                f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {idea}\n")
            self.page.close(dialog)
            self.show_system_notification("Idea Notebook", "Идея сохранена")

        dialog = ft.AlertDialog(
            title=ft.Text("Idea Notebook"),
            content=idea_field,
            actions=[
                ft.TextButton("Отмена", on_click=lambda e: self.page.close(dialog)),
                ft.FilledButton("Сохранить", on_click=save_idea),
            ],
        )
        self.page.open(dialog)

    def open_recycle_bin(self):
        import subprocess
        import platform

        try:
            system = platform.system().lower()
            if system == "windows":
                os.system("start shell:RecycleBinFolder")
            elif system == "darwin":
                subprocess.Popen(["open", os.path.expanduser("~/.Trash")])
            else:
                candidates = [
                    "trash://",
                    os.path.expanduser("~/.local/share/Trash/files"),
                    os.path.expanduser("~/.Trash"),
                ]
                opened = False
                for candidate in candidates:
                    try:
                        if candidate.startswith("trash://"):
                            subprocess.Popen(["xdg-open", candidate])
                        elif os.path.exists(candidate):
                            subprocess.Popen(["xdg-open", candidate])
                        opened = True
                        break
                    except Exception:
                        continue
                if not opened:
                    raise RuntimeError("Корзина не найдена")
            self.show_system_notification("Корзина", "Открыта корзина системы")
        except Exception:
            logger.exception("Ошибка открытия корзины")
            self.show_system_notification("Корзина", "Не удалось открыть корзину")

    def toggle_floating_hud(self):
        self.floating_hud_visible = not self.floating_hud_visible
        self.update_main_content()

    def run_workspace_preset(self, preset_id):
        result = self.smart_workspace_manager.run_preset(preset_id)
        self.show_system_notification("Smart Workspace", result.get("message", "Готово"))

    # Делегируемые методы для тем и настроек
    def apply_theme_settings(self, theme_name):
        self.theme_manager.apply_theme(self.page, theme_name)
        self.update_interface_colors()
        self.update_main_content()
        self.page.show_snack_bar(ft.SnackBar(content=ft.Text(f"Тема применена: {theme_name}"), action="OK"))

    def toggle_glass_effect(self):
        enabled = self.theme_manager.toggle_glass_effect()
        self.update_main_content()
        self.update_sidebar()
        message = "Размытие (Old version) включено" if enabled else "Размытие (Old version) выключено"
        self.page.show_snack_bar(ft.SnackBar(content=ft.Text(message), action="OK"))

    def set_glass_intensity(self, intensity):
        self.theme_manager.set_glass_intensity(intensity)
        self.update_main_content()
        self.update_sidebar()
        intensity_names = {"light": "Слабая", "medium": "Средняя", "strong": "Сильная"}
        self.page.show_snack_bar(ft.SnackBar(content=ft.Text(f"Интенсивность установлена: {intensity_names[intensity]}"), action="OK"))

    def toggle_smooth_animations(self):
        enabled = self.theme_manager.toggle_smooth_animations()
        message = "Плавные анимации включены" if enabled else "Плавные анимации выключены"
        self.page.show_snack_bar(ft.SnackBar(content=ft.Text(message), action="OK"))

    def toggle_android_animations(self):
        enabled = self.theme_manager.toggle_android_animations()
        message = "Android-анимации включены" if enabled else "Android-анимации выключены"
        self.page.show_snack_bar(ft.SnackBar(content=ft.Text(message), action="OK"))

    def toggle_auto_update(self, e):
        self.auto_update_enabled = e.control.value
        if self.auto_update_enabled:
            self.show_system_notification("Автообновление включено", "Интерфейс будет обновляться автоматически")

    def toggle_system_notifications(self, e):
        self.system_notifications_enabled = e.control.value
        if self.system_notifications_enabled:
            self.show_system_notification("Уведомления включены", "Вы будете получать уведомления о действиях")

    def refresh_apps_list(self):
        # Сбрасываем кэш поиска при обновлении списка приложений
        self.search_cache.invalidate_search_cache()
        self.update_main_content()
        self.update_sidebar()
        self.page.show_snack_bar(ft.SnackBar(content=ft.Text("✅ Список приложений обновлен"), action="OK"))

    def reset_favorites(self):
        self.app_manager.favorite_apps = []
        self.app_manager.save_favorites()
        self.update_main_content()
        self.page.show_snack_bar(ft.SnackBar(content=ft.Text("✅ Избранное сброшено"), action="OK"))

    def clear_manual_paths(self):
        self.app_manager.manual_paths = {}
        self.app_manager.save_manual_paths()
        self.update_main_content()
        self.update_sidebar()
        self.page.show_snack_bar(ft.SnackBar(content=ft.Text("✅ Ручные пути очищены"), action="OK"))

    def show_settings(self, e):
        self.dialogs.show_settings(e)

    def show_plugins_manager(self, e):
        self.dialogs.show_plugins_manager(e)

    def show_workspace_manager(self, e=None):
        self.dialogs.show_workspace_manager(e)

    def show_add_custom_app_dialog(self, e):
        self.dialogs.show_add_custom_app_dialog(e)

    def show_app_menu_dialog(self, app):
        self.dialogs.show_app_menu_dialog(app)

    def show_favorite_app_menu_dialog(self, app):
        self.dialogs.show_favorite_app_menu_dialog(app)

    def select_manual_path(self, app):
        self.dialogs.select_manual_path(app)

    def show_edit_custom_app_dialog(self, app):
        self.dialogs.show_edit_custom_app_dialog(app)

    def show_edit_tags_dialog(self, app):
        self.dialogs.show_edit_tags_dialog(app)

    # Новые методы для версии 2.2
    def reload_interface(self):
        """Перезагрузить интерфейс"""
        self.page.clean()
        self.initialize_ui()

    def create_backup_now(self, e=None):
        """Создать резервную копию сейчас"""
        backup_path = self.backup_manager.create_backup()
        if backup_path:
            self.page.show_snack_bar(ft.SnackBar(
                content=ft.Text(f"✅ Резервная копия создана: {os.path.basename(backup_path)}"),
                action="OK"
            ))
        else:
            self.page.show_snack_bar(ft.SnackBar(
                content=ft.Text("❌ Ошибка создания резервной копии"),
                action="OK"
            ))

    def restore_from_backup(self, backup_path):
        """Восстановить из резервной копии"""
        if self.backup_manager.restore_backup(backup_path):
            self.page.show_snack_bar(ft.SnackBar(
                content=ft.Text("✅ Настройки восстановлены из резервной копии"),
                action="OK"
            ))
            # Перезагружаем настройки
            self.theme_manager.load_settings()
            self.apply_initial_theme()
        else:
            self.page.show_snack_bar(ft.SnackBar(
                content=ft.Text("❌ Ошибка восстановления из резервной копии"),
                action="OK"
            ))

    def get_backup_list(self):
        """Получить список резервных копий"""
        return self.backup_manager.get_backup_list()

    def delete_backup(self, backup_filename):
        """Удалить резервную копию"""
        return self.backup_manager.delete_backup(backup_filename)

    def update_header(self):
        """Обновить header"""
        if self.header:
            self.header.content = self.panels.create_header()
            self.page.update()

    def set_time_format(self, format_type):
        """Установить формат времени"""
        self.theme_manager.set_time_format(format_type)
        self.update_time()

    def set_font_family(self, font_family):
        """Установить семейство шрифтов"""
        self.theme_manager.set_font_family(font_family)
        self.page.theme = ft.Theme(font_family=font_family)
        self.page.update()

    def set_font_size(self, font_size):
        """Установить размер шрифта"""
        self.theme_manager.set_font_size(font_size)
        self.update_interface_colors()

    def set_performance_settings(self, search_cache, virtualization):
        """Установить настройки производительности"""
        self.theme_manager.set_performance_settings(search_cache, virtualization)
        if not search_cache:
            self.search_cache.cache_manager.clear()

    def set_backup_settings(self, auto_backup, interval):
        """Установить настройки резервного копирования"""
        self.theme_manager.set_backup_settings(auto_backup, interval)


    def load_search_history(self):
        history = self.app_manager.file_manager.load_data(self.search_history_file, [])
        return history if isinstance(history, list) else []

    def save_search_history(self):
        self.app_manager.file_manager.save_data(self.search_history_file, self.search_history)

    def clear_search_cache(self):
        """Очистить кэш поиска"""
        self.search_cache.invalidate_search_cache()
        self.search_history.clear()
        self.save_search_history()

    def get_apps_count(self):
        """Получить количество приложений"""
        return len(self.app_manager.all_apps + self.app_manager.custom_apps)

    def get_favorites_count(self):
        """Получить количество избранных приложений"""
        return len(self.app_manager.favorite_apps)

    def get_custom_apps_count(self):
        """Получить количество кастомных приложений"""
        return len(self.app_manager.custom_apps)

    def get_performance_info(self):
        """Получить информацию о производительности"""
        return {
            "search_cache_enabled": self.theme_manager.search_cache_enabled,
            "virtualization_enabled": self.theme_manager.virtualization_enabled,
            "cached_searches": len([k for k in self.search_cache.cache_manager.cache.keys() if k.startswith("search_")]),
            "search_history": len(self.search_history),
            "total_apps": self.get_apps_count()
        }
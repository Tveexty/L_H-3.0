import os
import uuid
import flet as ft


ICON_PRESETS = [
    "apps", "terminal", "code", "sports_esports", "chat", "web", "movie", "music_note", "school", "work",
    "settings", "folder", "photo", "brush", "book", "shopping_cart", "home", "travel_explore", "videogame_asset", "smart_toy",
    "security", "local_fire_department", "developer_mode", "cloud", "build", "language", "computer", "desktop_windows", "storage", "analytics",
    "camera_alt", "headphones", "mic", "podcasts", "tv", "smart_display", "newspaper", "rss_feed", "calculate", "science",
    "account_balance_wallet", "payments", "attach_money", "flight", "directions_car", "train", "map", "place", "fitness_center", "self_improvement",
    "medical_services", "healing", "restaurant", "coffee", "local_grocery_store", "pets", "park", "emoji_events", "military_tech", "shield",
    "vpn_key", "lock", "bolt", "flash_on", "rocket_launch", "auto_awesome", "extension", "widgets", "dashboard", "view_kanban",
]



class AddAppDialogMixin:
    def show_add_custom_app_dialog(self, e):
        """Компактное и единое окно добавления приложения (без вложенных окон)."""
        colors = self.core.get_colors()

        app_name = ft.TextField(
            label="Название приложения *",
            hint_text="Например: VS Code",
            filled=True,
            bgcolor=colors["SURFACE_VARIANT"],
            border_color="transparent",
            border_radius=10,
        )
        app_url = ft.TextField(
            label="URL или путь *",
            hint_text="https://... или C:\\Program Files\\App\\app.exe",
            filled=True,
            bgcolor=colors["SURFACE_VARIANT"],
            border_color="transparent",
            border_radius=10,
        )
        app_category = ft.Dropdown(
            label="Категория",
            value="Custom",
            options=[
                ft.dropdown.Option("Custom"),
                ft.dropdown.Option("Games"),
                ft.dropdown.Option("Development"),
                ft.dropdown.Option("Media"),
                ft.dropdown.Option("Productivity"),
                ft.dropdown.Option("System"),
            ],
            filled=True,
            bgcolor=colors["SURFACE_VARIANT"],
            border_color="transparent",
            border_radius=10,
        )

        selected_icon = {"value": "apps"}
        preview_icon = ft.Icon("apps", size=30, color=colors["ACCENT"])
        selected_icon_label = ft.Text("apps", color=colors["ACCENT"])

        def set_icon(icon_name: str):
            selected_icon["value"] = icon_name
            preview_icon.name = icon_name
            selected_icon_label.value = icon_name
            preview_icon.update()
            selected_icon_label.update()

        icon_grid = ft.GridView(runs_count=6, max_extent=52, spacing=8, run_spacing=8, height=180)
        for icon in ICON_PRESETS:
            icon_grid.controls.append(
                ft.Container(
                    content=ft.IconButton(icon=icon, icon_size=20, icon_color=colors["ON_SURFACE"], on_click=lambda e, i=icon: set_icon(i)),
                    bgcolor=colors["SURFACE_VARIANT"] + "30",
                    border_radius=10,
                )
            )

        def auto_detect_type():
            return "web" if app_url.value and app_url.value.lower().startswith(("http://", "https://")) else "app"

        def on_pick_result(e: ft.FilePickerResultEvent):
            if e.files:
                app_url.value = e.files[0].path
                app_url.update()

        file_picker = ft.FilePicker(on_result=on_pick_result)
        if file_picker not in self.core.page.overlay:
            self.core.page.overlay.append(file_picker)

        def pick_file(_):
            try:
                file_picker.pick_files(allow_multiple=False)
            except Exception:
                self.core.page.show_snack_bar(ft.SnackBar(content=ft.Text("Не удалось открыть проводник. Введите путь вручную."), action="OK"))
        def add_app(_):
            if not app_name.value or not app_url.value:
                self.core.page.show_snack_bar(ft.SnackBar(content=ft.Text("❌ Заполните обязательные поля"), action="OK"))
                return

            new_app = {
                "name": app_name.value.strip(),
                "package": app_name.value.strip().lower().replace(" ", "_"),
                "category": app_category.value or "Custom",
                "icon": selected_icon["value"],
                "url": app_url.value.strip(),
                "type": auto_detect_type(),
                "id": str(uuid.uuid4()),
                "official_url": app_url.value.strip() if auto_detect_type() == "web" else "",
            }

            self.core.app_manager.custom_apps.append(new_app)
            self.core.app_manager.save_custom_apps()
            self.core.update_main_content()
            self.core.update_sidebar()
            self.core.page.close(dialog)
            self.core.page.show_snack_bar(ft.SnackBar(content=ft.Text("✅ Приложение добавлено"), action="OK"))

        dialog = ft.AlertDialog(
            title=ft.Text("Добавить приложение"),
            content=ft.Container(
                width=700,
                content=ft.Column([
                    ft.Container(
                        bgcolor=colors["ACCENT"] + "12",
                        border_radius=10,
                        padding=10,
                        content=ft.Text("Единое окно: настройки приложения и выбор иконки в одном месте", size=12, color=colors["ON_SURFACE_VARIANT"]),
                    ),
                    app_name,
                    ft.Row([app_url, ft.IconButton(icon="folder_open", on_click=pick_file, tooltip="Выбрать файл")]),
                    app_category,
                    ft.Row([
                        ft.Text("Превью", color=colors["ON_SURFACE_VARIANT"]),
                        preview_icon,
                        selected_icon_label,
                    ]),
                    ft.Text("Выбор иконки", weight=ft.FontWeight.W_500),
                    icon_grid,
                ], scroll=ft.ScrollMode.ADAPTIVE, tight=True),
            ),
            actions=[
                ft.TextButton("Отмена", on_click=lambda e: self.core.page.close(dialog)),
                ft.FilledButton("Добавить", on_click=add_app),
            ],
        )
        self.core.page.open(dialog)
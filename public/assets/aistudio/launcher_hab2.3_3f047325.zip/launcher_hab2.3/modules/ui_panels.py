# [file name]: ui_panels.py
import flet as ft
from .glass_morphism import GlassMorphism

class UIPanels:
    def _with_opacity(self, hex_color: str, percent: int) -> str:
        if not isinstance(hex_color, str) or not hex_color.startswith("#") or len(hex_color) != 7:
            return hex_color
        alpha = max(0, min(255, int(percent * 2.55)))
        return f"{hex_color}{alpha:02x}"

    def __init__(self, ui_core):
        self.core = ui_core
        self.current_time_text = None
        self.current_date_text = None
        self.devices_container = None
        self.volume_slider_container = None
        self.search_field = None
        self.apps_list = None

    def create_header(self):
        colors = self.core.get_colors()
        self.create_time_elements()
        
        # Время и дата
        time_display = ft.Container(
            content=ft.Column([self.current_time_text, self.current_date_text], 
                            spacing=2, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
            padding=15, alignment=ft.alignment.center
        )
        
        
        # Устройства
        self.devices_container = ft.Container(
            content=self.core.system_monitor.create_devices_header(colors),
            padding=10, alignment=ft.alignment.center
        )
        
        # Кнопка плагинов
        plugins_button = ft.IconButton(
            icon="extension",
            icon_color=colors["ON_SURFACE"],
            on_click=self.core.show_plugins_manager,
            tooltip="Управление плагинами",
        )
        
        # Кнопка звука
        audio_button = ft.IconButton(
            icon="volume_up",
            icon_color=colors["ON_SURFACE"],
            on_click=self.core.toggle_volume_slider,
            tooltip="Управление громкостью",
        )
        
        # Слайдер громкости
        self.volume_slider_container = ft.Container(
            content=ft.Row([
                ft.Icon("volume_down", size=16, color=colors["ON_SURFACE_VARIANT"]),
                ft.Container(
                    content=ft.Slider(
                        value=self.core.audio_controller.get_volume_level(),
                        min=0,
                        max=100,
                        divisions=100,
                        label="{value}%",
                        on_change=self.core.on_volume_change,
                        active_color=colors["ACCENT"],
                        inactive_color=colors["SURFACE_VARIANT"],
                        width=120
                    ),
                    padding=ft.padding.symmetric(horizontal=5)
                ),
                ft.Icon("volume_up", size=16, color=colors["ON_SURFACE_VARIANT"]),
            ], spacing=5),
            bgcolor=colors["SURFACE_VARIANT"],
            border_radius=8,
            padding=10,
            visible=False,
            animate_opacity=300,
        )
        
        workspace_button = ft.IconButton(
            icon="rocket_launch",
            icon_color=colors["ACCENT"],
            tooltip="Smart Workspace",
            on_click=self.core.dialogs.show_workspace_manager,
        )

        hud_button = ft.IconButton(
            icon="monitor_heart",
            icon_color=colors["ON_SURFACE"],
            tooltip="Floating HUD",
            on_click=lambda e: self.core.toggle_floating_hud(),
        )

        header_content = [
            ft.Row([workspace_button, ft.Text("Launcher Hab 2.3", size=24, weight=ft.FontWeight.BOLD, color=colors["ON_SURFACE"])], spacing=8, expand=True),
            self.devices_container,
        ]
        
        
        header_content.extend([
            time_display,
            plugins_button,
            ft.Row([audio_button, self.volume_slider_container], spacing=5),
            hud_button,
            ft.IconButton(
                icon="settings", icon_color=colors["ON_SURFACE"],
                on_click=self.core.show_settings, tooltip="Настройки",
            )
        ])
        
        return ft.Container(
            content=ft.Row(header_content),
            bgcolor=colors["SURFACE"], padding=15, margin=0
        )

    def create_time_elements(self):
        colors = self.core.get_colors()
        clock_style = getattr(self.core.theme_manager, "clock_style", "standard")
        self.current_time_text = ft.Text(
            "",
            size=34 if clock_style == "stacked" else getattr(self.core.theme_manager, "time_font_size", 18),
            font_family=getattr(self.core.theme_manager, "time_font_family", self.core.theme_manager.font_family),
            text_align=ft.TextAlign.CENTER if clock_style == "stacked" else ft.TextAlign.RIGHT,
            weight=ft.FontWeight.BOLD if clock_style == "stacked" else ft.FontWeight.W_600,
            color=getattr(self.core.theme_manager, "time_color", colors["ON_SURFACE"]),
        )
        self.current_date_text = ft.Text(
            "",
            size=getattr(self.core.theme_manager, "date_font_size", 12),
            font_family=getattr(self.core.theme_manager, "date_font_family", self.core.theme_manager.font_family),
            text_align=ft.TextAlign.CENTER if clock_style == "stacked" else ft.TextAlign.RIGHT,
            color=getattr(self.core.theme_manager, "date_color", colors["ON_SURFACE_VARIANT"]),
            visible=getattr(self.core.theme_manager, "show_date", True),
        )

    def create_sidebar(self):
        return ft.Container(
            content=self.create_sidebar_content(),
            width=350, bgcolor=self.core.get_colors()["SURFACE"], padding=0, margin=0
        )

    def create_sidebar_content(self):
        colors = self.core.get_colors()
        
        self.search_field = ft.TextField(
            hint_text="Поиск приложений...", prefix_icon="search", filled=True,
            bgcolor=colors["SURFACE_VARIANT"], border_radius=12,
            on_change=self.core.filter_apps, content_padding=15, expand=True,
            border_color="transparent"
        )
        
        filter_button = self.create_filter_button()
        self.apps_list = self.create_apps_list()
        
        return ft.Column([
            ft.Container(
                content=ft.Text("Приложения", size=18, weight=ft.FontWeight.BOLD, 
                               color=colors["ON_SURFACE"]),
                padding=20, alignment=ft.alignment.center
            ),
            ft.Container(
                content=ft.Row([self.search_field, filter_button], spacing=10),
                padding=ft.padding.symmetric(horizontal=15, vertical=10)
            ),
            ft.Divider(color=colors["OUTLINE"], height=1),
            ft.Container(content=self.apps_list, expand=True),
            ft.Divider(color=colors["OUTLINE"], height=1),
            ft.Container(content=self.create_add_app_button(),
                       padding=ft.padding.symmetric(horizontal=15, vertical=10)),
        ])

    def create_apps_list(self):
        apps_list = ft.ListView(expand=True, spacing=2, padding=5)
        
        # Применяем виртуализацию если включена
        all_apps = self.core.app_manager.all_apps + self.core.app_manager.custom_apps
        filtered_apps = self.filter_apps_by_type(all_apps)
        
        for app in filtered_apps:
            apps_list.controls.append(self.create_app_list_item(app))
        
        return apps_list

    def create_app_list_item(self, app):
        colors = self.core.get_colors()
        is_installed = self.core.app_manager.is_app_installed(app)
        
        if self.core.theme_manager.advanced_glass_enabled:
            bg_color = self._with_opacity(colors["SURFACE"], self.core.theme_manager.advanced_glass_opacity)
        else:
            bg_color = colors["GLASS_BG"] if self.core.theme_manager.glass_effect_enabled else colors["SURFACE_VARIANT"] + "30"
        
        app_item = ft.Container(
            content=ft.Row([
                ft.Container(
                    content=ft.Icon(app["icon"], color=colors["WEB_BLUE"] if app["type"] == "web" 
                                   else (colors["ON_SURFACE"] if is_installed else colors["ERROR"]), size=28),
                    width=50, height=50, alignment=ft.alignment.center,
                    bgcolor=bg_color, border_radius=12,
                    shadow=ft.BoxShadow(blur_radius=8, color=colors["GLASS_SHADOW"], offset=ft.Offset(0, 2)),
                ),
                ft.Column([
                    ft.Text(app["name"], color=colors["ON_SURFACE"] if is_installed else colors["ERROR"],
                           size=14, weight=ft.FontWeight.W_500),
                    ft.Text(f"{app['category']} • {'Установлено' if is_installed else 'Не установлено'}", 
                           color=colors["ON_SURFACE_VARIANT"] if is_installed else colors["ERROR"], size=11),
                ], expand=True, spacing=2),
                ft.IconButton(
                    icon="more_vert", icon_size=18, icon_color=colors["ON_SURFACE_VARIANT"],
                    on_click=lambda e, app=app: self.core.show_app_menu_dialog(app), tooltip="Меню приложения",
                    style=ft.ButtonStyle(padding=ft.padding.all(8), bgcolor="transparent")
                )
            ], spacing=12, vertical_alignment=ft.CrossAxisAlignment.CENTER),
            padding=ft.padding.symmetric(horizontal=15, vertical=12), border_radius=8,
            on_click=lambda e, app=app: self.core.launch_app(app), tooltip=f"Запустить {app['name']}",
            bgcolor=bg_color, margin=ft.margin.symmetric(vertical=2), height=80,
        )
        
        def on_hover(e):
            if e.data == "true":
                app_item.bgcolor = colors["ACCENT"] + "20"
            else:
                app_item.bgcolor = bg_color
            app_item.update()
        
        app_item.on_hover = on_hover
        return app_item

    def create_add_app_button(self):
        colors = self.core.get_colors()
        
        bg_color = colors["GLASS_BG_LIGHT"] if self.core.theme_manager.glass_effect_enabled else colors["SURFACE_VARIANT"] + "15"
        
        add_button = ft.Container(
            content=ft.Row([
                ft.Container(
                    content=ft.Icon("add", color=colors["ON_SURFACE"], size=28),
                    width=60, height=60, alignment=ft.alignment.center,
                    bgcolor=colors["ACCENT"] + "20", border_radius=12,
                ),
                ft.Column([
                    ft.Text("Добавить приложение", color=colors["ON_SURFACE"], size=14, weight=ft.FontWeight.W_500),
                    ft.Text("Создайте свое приложение", color=colors["ON_SURFACE_VARIANT"], size=11),
                ], expand=True, spacing=2),
            ], spacing=12, vertical_alignment=ft.CrossAxisAlignment.CENTER),
            padding=ft.padding.symmetric(horizontal=15, vertical=12), border_radius=8,
            on_click=self.core.show_add_custom_app_dialog, tooltip="Добавить новое приложение",
            bgcolor=bg_color, margin=ft.margin.symmetric(vertical=2), height=80,
        )
        
        def on_hover(e):
            if e.data == "true":
                add_button.bgcolor = colors["ACCENT"] + "30"
            else:
                add_button.bgcolor = bg_color
            add_button.update()
        
        add_button.on_hover = on_hover
        return add_button

    def create_filter_button(self):
        colors = self.core.get_colors()
        
        filter_btn = ft.Container(
            content=ft.Icon("filter_list", color=colors["ON_SURFACE"], size=20),
            width=44, height=44, alignment=ft.alignment.center,
            bgcolor=colors["SURFACE_VARIANT"] + "30", border_radius=12,
            on_click=self.core.show_filter_menu, tooltip="Фильтровать по типу",
        )
        
        def on_hover(e):
            if e.data == "true":
                filter_btn.bgcolor = colors["ACCENT"] + "20"
            else:
                filter_btn.bgcolor = colors["SURFACE_VARIANT"] + "30"
            filter_btn.update()
        
        filter_btn.on_hover = on_hover
        return filter_btn

    def create_main_content(self):
        return ft.Container(
            content=self.create_main_content_internal(),
            expand=True, padding=10, margin=0
        )

    def create_main_content_internal(self):
        colors = self.core.get_colors()
        
        favorites_content = self.create_favorites_panel()
        category_sections = self.create_category_sections()
        
        main_content_list = [favorites_content]
        
        if category_sections:
            main_content_list.extend(category_sections)
        elif self.core.current_filter != "all":
            no_apps_content = ft.Column([
                ft.Icon("search_off", size=64, color=colors["ON_SURFACE_VARIANT"]),
                ft.Text("Нет приложений по выбранному фильтру", size=18, color=colors["ON_SURFACE_VARIANT"], weight=ft.FontWeight.W_500),
                ft.Text("Попробуйте выбрать другой фильтр или добавьте свои приложения", size=14, color=colors["ON_SURFACE_VARIANT"]),
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=15)
            
            no_apps_card = GlassMorphism.create_card(no_apps_content, colors, hover_effect=False) if self.core.theme_manager.glass_effect_enabled else ft.Container(content=no_apps_content, padding=80, alignment=ft.alignment.center)
            
            main_content_list.append(no_apps_card)
    
        main_column = ft.Column(main_content_list, scroll=ft.ScrollMode.ADAPTIVE)

        if self.core.floating_hud_visible:
            perf = self.core.system_monitor.get_performance_info()
            self.core.floating_hud_cpu_text = ft.Text(f"CPU {perf['cpu']}%", size=11, color=colors["ON_SURFACE"])
            self.core.floating_hud_ram_text = ft.Text(f"RAM {perf['ram']}%", size=11, color=colors["ON_SURFACE"])
            self.core.floating_hud_apps_text = ft.Text(f"Launch apps {len(self.core.app_manager.favorite_apps)}", size=11, color=colors["ON_SURFACE"])
            hud = ft.Container(
                content=ft.Column([
                    ft.Text("Floating HUD", weight=ft.FontWeight.BOLD, size=12, color=colors["ON_SURFACE"]),
                      self.core.floating_hud_cpu_text,
                    self.core.floating_hud_ram_text,
                    self.core.floating_hud_apps_text,
                ], spacing=2),
                right=10,
                top=20,
                padding=10,
                bgcolor=self._with_opacity(colors["SURFACE"], 80),
                border_radius=10,
                border=ft.border.all(1, colors["OUTLINE"]),
            )
            return ft.Stack([main_column, hud])
        self.core.floating_hud_cpu_text = None
        self.core.floating_hud_ram_text = None
        self.core.floating_hud_apps_text = None
        return main_column

    def create_favorites_panel(self):
        colors = self.core.get_colors()
        favorite_apps = self.core.app_manager.favorite_apps
        
        favorites_counter = ft.Container(
            content=ft.Text(
                f"{len(favorite_apps)}/10",
                size=12,
                color=colors["ON_SURFACE_VARIANT"],
                weight=ft.FontWeight.W_500
            ),
            bgcolor=colors["GLASS_BG"],
            padding=ft.padding.symmetric(horizontal=8, vertical=4),
            border_radius=8,
        )
        
        if not favorite_apps:
            empty_content = ft.Column([
                ft.Container(content=ft.Row([
                    ft.Icon("star", color=colors["ACCENT"], size=20),
                    ft.Text("Избранное", size=16, weight=ft.FontWeight.BOLD, color=colors["ON_SURFACE"]),
                    favorites_counter
                ]), padding=ft.padding.symmetric(horizontal=15, vertical=10)),
                ft.Container(
                    content=ft.Column([
                        ft.Icon("star_border", size=32, color=colors["ON_SURFACE_VARIANT"]),
                        ft.Text("Добавьте приложения в избранное", size=12, 
                               color=colors["ON_SURFACE_VARIANT"], text_align=ft.TextAlign.CENTER),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=8),
                    padding=15, alignment=ft.alignment.center
                )
            ])
            
            return GlassMorphism.create_card(empty_content, colors, hover_effect=False) if self.core.theme_manager.glass_effect_enabled else ft.Container(content=empty_content, bgcolor=colors["SURFACE"], border_radius=12, margin=ft.margin.symmetric(horizontal=10, vertical=5))
        
        favorites_grid = ft.GridView(
            runs_count=6, 
            max_extent=120, 
            child_aspect_ratio=0.9,
            spacing=15, 
            run_spacing=20, 
            padding=20
        )
        
        for app in favorite_apps:
            is_installed = self.core.app_manager.is_app_installed(app)
            
            app_content = ft.Column([
                ft.Container(
                    content=ft.Stack([
                        ft.Icon(name=app["icon"], size=42, 
                               color=colors["WEB_BLUE"] if app["type"] == "web" 
                               else (colors["ON_SURFACE"] if is_installed else colors["ERROR"])),
                        ft.Container(
                            content=ft.Icon(
                                name="check_circle" if is_installed else "error",
                                size=16,
                                color=colors["SUCCESS"] if is_installed else colors["ERROR"]
                            ),
                            alignment=ft.alignment.bottom_right,
                            margin=ft.margin.only(top=-18, right=-5),
                        )
                    ]),
                    width=80,
                    height=80,
                    alignment=ft.alignment.center,
                    bgcolor=colors["GLASS_BG"] if self.core.theme_manager.glass_effect_enabled else colors["SURFACE_VARIANT"] + "30",
                    border_radius=15,
                    border=ft.border.all(1, GlassMorphism._apply_opacity(colors["OUTLINE"], 0.1)) if self.core.theme_manager.glass_effect_enabled else None,
                    shadow=ft.BoxShadow(blur_radius=8, color=colors["GLASS_SHADOW"], offset=ft.Offset(0, 2)),
                ),
                ft.Container(
                    content=ft.Column([
                        ft.Text(
                            app["name"],
                            size=12,
                            color=colors["WEB_BLUE"] if app["type"] == "web" 
                            else (colors["ON_SURFACE"] if is_installed else colors["ERROR"]),
                            text_align=ft.TextAlign.CENTER,
                            max_lines=1,
                            overflow=ft.TextOverflow.ELLIPSIS,
                        ),
                        ft.Text(
                            f"{app['type'].upper()}",
                            size=9,
                            color=colors["ON_SURFACE_VARIANT"],
                            text_align=ft.TextAlign.CENTER,
                        ),
                    ], spacing=2),
                    height=35,
                    alignment=ft.alignment.top_center,
                    padding=ft.padding.only(top=5)
                )
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=5, height=130)
            
            app_container = ft.Container(
                content=app_content,
                width=110,
                height=140,
                padding=10,
                on_click=lambda e, app=app: self.core.launch_app(app),
                on_long_press=lambda e, app=app: self.core.show_favorite_app_menu_dialog(app),
                tooltip=f"Запустить {app['name']} ({app['type']})\nДолгое нажатие для меню",
                border_radius=12,
                bgcolor="transparent",
                animate=ft.Animation(200, "easeOut"),
            )
            
            def create_hover_handler(button):
                def on_hover(e):
                    if e.data == "true":
                        button.scale = 1.05
                        button.shadow = ft.BoxShadow(blur_radius=20, color=colors["ACCENT_GLOW"], offset=ft.Offset(0, 5))
                    else:
                        button.scale = 1.0
                        button.shadow = ft.BoxShadow(blur_radius=8, color=colors["GLASS_SHADOW"], offset=ft.Offset(0, 2))
                    button.update()
                return on_hover
            
            app_container.on_hover = create_hover_handler(app_container)
            favorites_grid.controls.append(app_container)
        
        favorites_content = ft.Column([
            ft.Container(content=ft.Row([
                ft.Icon("star", color=colors["ACCENT"], size=20),
                ft.Text("Избранное", size=16, weight=ft.FontWeight.BOLD, color=colors["ON_SURFACE"]),
                favorites_counter
            ]), padding=ft.padding.symmetric(horizontal=15, vertical=10)),
            favorites_grid
        ])
        
        return GlassMorphism.create_card(favorites_content, colors, hover_effect=False) if self.core.theme_manager.glass_effect_enabled else ft.Container(content=favorites_content, bgcolor=colors["SURFACE"], border_radius=12, margin=ft.margin.symmetric(horizontal=10, vertical=5))

    def create_category_sections(self):
        colors = self.core.get_colors()
        all_available_apps = self.core.app_manager.all_apps + self.core.app_manager.custom_apps
        filtered_apps = self.filter_apps_by_type(all_available_apps)
        
        categories = {}
        for app in filtered_apps:
            if app["category"] not in categories:
                categories[app["category"]] = []
            categories[app["category"]].append(app)
        
        category_sections = []
        for category, apps in categories.items():
            if apps:
                apps_grid = ft.GridView(
                    runs_count=6, 
                    max_extent=120, 
                    child_aspect_ratio=0.9, 
                    spacing=15, 
                    run_spacing=20, 
                    padding=20
                )
                
                for app in apps:
                    is_installed = self.core.app_manager.is_app_installed(app)
                    app_button = GlassMorphism.create_app_button(
                        app, colors, is_installed,
                        glass_effect=self.core.theme_manager.glass_effect_enabled,
                        on_click=lambda e, app=app: self.core.launch_app(app)
                    )
                    
                    def create_hover_handler(button):
                        def on_hover(e):
                            if e.data == "true":
                                button.scale = 1.05
                                button.shadow = ft.BoxShadow(blur_radius=20, color=colors["ACCENT_GLOW"], offset=ft.Offset(0, 5))
                            else:
                                button.scale = 1.0
                                button.shadow = ft.BoxShadow(blur_radius=8, color=colors["GLASS_SHADOW"], offset=ft.Offset(0, 2))
                            button.update()
                        return on_hover
                    
                    app_button.on_hover = create_hover_handler(app_button)
                    apps_grid.controls.append(app_button)
                
                category_header = ft.Container(
                    content=ft.Row([
                        ft.Icon(self.get_category_icon(category), color=colors["ACCENT"], size=20),
                        ft.Text(category, size=20, weight=ft.FontWeight.BOLD, color=colors["ON_SURFACE"]),
                        ft.Container(
                            content=ft.Text(f"{len(apps)}", size=14, color=colors["ON_SURFACE_VARIANT"], weight=ft.FontWeight.W_500),
                            bgcolor=colors["SURFACE_VARIANT"],
                            padding=ft.padding.symmetric(horizontal=10, vertical=4),
                            border_radius=12,
                        )
                    ]),
                    padding=ft.padding.only(left=30, top=30, bottom=15, right=30),
                )
                
                category_content = ft.Column([category_header, apps_grid])
                
                if self.core.theme_manager.glass_effect_enabled:
                    category_card = GlassMorphism.create_card(category_content, colors, hover_effect=False)
                else:
                    category_card = ft.Container(
                        content=category_content,
                        shadow=ft.BoxShadow(blur_radius=8, color=colors["GLASS_SHADOW"], offset=ft.Offset(0, 2)),
                        margin=ft.margin.only(bottom=25), border_radius=12, bgcolor=colors["SURFACE"],
                    )
                
                category_sections.append(category_card)
        
        return category_sections

    def filter_apps_by_type(self, apps_list):
        if self.core.current_filter == "all":
            return apps_list
        elif self.core.current_filter == "web":
            return [app for app in apps_list if app["type"] == "web"]
        elif self.core.current_filter == "app":
            return [app for app in apps_list if app["type"] == "app"]
        elif self.core.current_filter == "system":
            return [app for app in apps_list if app["type"] == "system"]
        elif self.core.current_filter == "custom":
            return [app for app in apps_list if app in self.core.app_manager.custom_apps]
        return apps_list

    def get_category_icon(self, category):
        icons = {
            "Browser": "web", "Media": "play_arrow", "Music": "music_note",
            "Social": "groups", "Games": "sports_esports", "System": "computer",
            "Office": "work", "Cloud": "cloud", "Health": "medical_services",
            "Government": "verified_user", "Utilities": "apps",
        }
        return icons.get(category, "apps")

    def show_search_results(self, results, query):
        colors = self.core.get_colors()
        
        if not results:
            no_results_content = ft.Column([
                ft.Icon("search_off", size=64, color=colors["ON_SURFACE_VARIANT"]),
                ft.Text("Ничего не найдено", size=18, color=colors["ON_SURFACE_VARIANT"], weight=ft.FontWeight.W_500),
                ft.Text(f"По запросу: '{query}'", size=14, color=colors["ON_SURFACE_VARIANT"]),
                ft.Text("Попробуйте изменить запрос", size=12, color=colors["ON_SURFACE_VARIANT"]),
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=15)
            
            self.core.main_content.content = ft.Column([
                self.create_favorites_panel(),
                GlassMorphism.create_card(no_results_content, colors, hover_effect=False) if self.core.theme_manager.glass_effect_enabled else ft.Container(content=no_results_content, padding=80, alignment=ft.alignment.center)
            ], scroll=ft.ScrollMode.ADAPTIVE)
        else:
            results_header = ft.Container(
                content=ft.Row([
                    ft.Icon("search", color=colors["ACCENT"], size=20),
                    ft.Text("Результаты поиска", size=20, weight=ft.FontWeight.BOLD, color=colors["ON_SURFACE"]),
                    ft.Container(
                        content=ft.Text(f"{len(results)} найдено", size=14, color=colors["ON_SURFACE_VARIANT"], weight=ft.FontWeight.W_500),
                        bgcolor=colors["SURFACE_VARIANT"],
                        padding=ft.padding.symmetric(horizontal=10, vertical=4),
                        border_radius=12,
                    )
                ]),
                padding=ft.padding.only(left=30, top=30, bottom=15, right=30),
            )
            
            results_grid = ft.GridView(
                runs_count=6, 
                max_extent=120, 
                child_aspect_ratio=0.9, 
                spacing=15, 
                run_spacing=20, 
                padding=20
            )
            
            for app in results:
                is_installed = self.core.app_manager.is_app_installed(app)
                app_button = GlassMorphism.create_app_button(
                    app, colors, is_installed,
                    glass_effect=self.core.theme_manager.glass_effect_enabled,
                    on_click=lambda e, app=app: self.core.launch_app(app)
                )
                
                def create_hover_handler(button):
                    def on_hover(e):
                        if e.data == "true":
                            button.scale = 1.05
                            button.shadow = ft.BoxShadow(blur_radius=20, color=colors["ACCENT_GLOW"], offset=ft.Offset(0, 5))
                        else:
                            button.scale = 1.0
                            button.shadow = ft.BoxShadow(blur_radius=8, color=colors["GLASS_SHADOW"], offset=ft.Offset(0, 2))
                        button.update()
                    return on_hover
                
                app_button.on_hover = create_hover_handler(app_button)
                results_grid.controls.append(app_button)
            
            search_results_content = ft.Column([results_header, results_grid])
            
            if self.core.theme_manager.glass_effect_enabled:
                search_card = GlassMorphism.create_card(search_results_content, colors, hover_effect=False)
            else:
                search_card = ft.Container(
                    content=search_results_content,
                    shadow=ft.BoxShadow(blur_radius=8, color=colors["GLASS_SHADOW"], offset=ft.Offset(0, 2)),
                    margin=ft.margin.only(bottom=25), border_radius=12, bgcolor=colors["SURFACE"],
                )
            
            self.core.main_content.content = ft.Column([
                self.create_favorites_panel(),
                search_card
            ], scroll=ft.ScrollMode.ADAPTIVE)
        
        if hasattr(self.core, 'page'):
            self.core.page.update()

    def create_loading_progress(self):
        colors = self.core.get_colors()
        return ft.Container(
            content=ft.Column([
                ft.Icon("rocket_launch", size=40, color=colors["ACCENT"]),
                ft.Text("Запуск приложения...", size=14, color=colors["ON_SURFACE"], weight=ft.FontWeight.W_500),
                ft.Container(
                    content=ft.ProgressBar(value=0, color=colors["ACCENT"], bgcolor=colors["SURFACE_VARIANT"], height=8, border_radius=4),
                    width=250, padding=ft.padding.only(top=10)
                )
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=10, alignment=ft.MainAxisAlignment.CENTER),
            bgcolor=colors["SURFACE"], border_radius=15, padding=25, visible=False,
            width=320, height=140, top=100, alignment=ft.alignment.top_center,
            shadow=ft.BoxShadow(blur_radius=15, color=colors["GLASS_SHADOW"], offset=ft.Offset(0, 5)),
        )

    def update_time_display(self):
        """Обновить отображение времени (вызывается из UIManagerCore)"""
        if hasattr(self.core, 'theme_manager'):
            now = datetime.now()
            
            # Форматирование времени
            if self.core.theme_manager.time_format == "12":
                time_str = now.strftime("%I:%M:%S %p")
            else:
                time_str = now.strftime("%H:%M:%S")
            
            # Форматирование даты
            date_format = self.core.theme_manager.date_format
            if date_format == "mm/dd/yyyy":
                date_str = now.strftime("%m/%d/%Y")
            elif date_format == "yyyy-mm-dd":
                date_str = now.strftime("%Y-%m-%d")
            else:
                date_str = now.strftime("%d.%m.%Y")
            
            if self.current_time_text:
                self.current_time_text.value = time_str
            if self.current_date_text:
                self.current_date_text.value = date_str